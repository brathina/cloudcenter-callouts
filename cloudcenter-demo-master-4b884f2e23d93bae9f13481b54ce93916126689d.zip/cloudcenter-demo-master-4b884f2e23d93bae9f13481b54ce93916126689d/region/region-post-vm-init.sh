#!/bin/bash -x

. /utils.sh

# TODO: remove env
echo "${parentJobName} ENV START"
env
echo "${parentJobName} ENV END"

# Run vm actions
curl -o remote_exec.sh "https://raw.githubusercontent.com/datacenter/cloudcenter-content/remote-exec1.1/other/helpers/remote_exec.sh"
if [ "${osName}" == "Windows" ]; then
    print_log "Windows detected."
    bash remote_exec.sh "http://10.36.60.55/root/cloudcenter-demo/raw/master/region/region-post-vm-init-vm-actions.ps1"
elif [ "${osName}" == "Linux" ]; then
    print_log "Linux detected."
    bash remote_exec.sh "http://10.36.60.55/root/cloudcenter-demo/raw/master/region/region-post-vm-init-vm-actions.sh"
    # Install AppD machine agent
    bash remote_exec.sh "https://raw.githubusercontent.com/datacenter/cloudcenter-content/appd/apps/appd/appd-service-centos.sh" \
        -h 10.36.60.51 \
        -u http://10.36.60.58:8081/artifactory/appd/download-file/machine/4.3.3.4/appdynamics-machine-agent-4.3.8.4-1.x86_64.rpm \
        -p 8090 \
        -n 6c65a39a-78e5-42ec-a183-70e3fb2483fc \
        -o add
fi

#curl -o remote_exec.sh "https://raw.githubusercontent.com/datacenter/cloudcenter-content/remote-exec0.3/other/helpers/remote_exec.sh"
#bash remote_exec.sh "https://raw.githubusercontent.com/datacenter/cloudcenter-content/appd1.1/apps/appd/appd-service-centos.sh"