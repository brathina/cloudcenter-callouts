#!/bin/bash -x

# Insert into ServiceNow CMDB
#curl -o servicenow.sh "https://raw.githubusercontent.com/datacenter/cloudcenter-content/master/other/servicenow/servicenow.sh"
#bash servicenow.sh

# Add to Ansible Tower inventory
yum install -y python-pip
pip install pip --upgrade
pip install requests
curl -o tower-server-registration.py "https://raw.githubusercontent.com/datacenter/cloudcenter-content/ansible1.2/apps/ansible-tower/tower-server-registration.py"
python tower-server-registration.py add 172.16.204.51 admin welcome2cliqr ${cliqrNodeHostname} 1
