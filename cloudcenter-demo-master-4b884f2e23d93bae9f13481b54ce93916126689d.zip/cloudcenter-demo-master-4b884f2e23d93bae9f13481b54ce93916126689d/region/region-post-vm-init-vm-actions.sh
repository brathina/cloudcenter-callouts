#!/bin/bash -x
exec > >(tee -a /var/tmp/region-pre-vm-init-vm-actions_$$.log) 2>&1

#sudo systemctl stop ntpd
#sudo sed -i.bak -e '/^server/d' /etc/ntp.conf
#echo "server 172.16.1.90" | sudo tee -a /etc/ntp.conf
#echo "server 172.16.1.91" | sudo tee -a /etc/ntp.conf
#sudo ntpdate 172.16.1.90
#sudo systemctl start ntpd
